package com.example.tify.Jiseok.Activity;

import android.content.Intent;
import android.util.Log;



public class KakaoLoginSuccess {




}
