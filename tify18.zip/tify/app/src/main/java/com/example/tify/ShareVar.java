package com.example.tify;

public class ShareVar {

    final static String macIP = "192.168.0.55";

    public ShareVar() {

    }

    public static String getMacIP() {
        return macIP;
    }
}
