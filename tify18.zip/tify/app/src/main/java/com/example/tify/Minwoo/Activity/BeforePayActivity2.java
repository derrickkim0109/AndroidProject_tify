package com.example.tify.Minwoo.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tify.Minwoo.Adapter.CartAdapter;
import com.example.tify.Minwoo.Bean.Cart;
import com.example.tify.Minwoo.Bean.Order;
import com.example.tify.Minwoo.Bean.OrderList;
import com.example.tify.Minwoo.NetworkTask.LMW_CartNetworkTask;
import com.example.tify.Minwoo.NetworkTask.LMW_OrderListNetworkTask;
import com.example.tify.Minwoo.NetworkTask.LMW_OrderNetworkTask;
import com.example.tify.Minwoo.NetworkTask.LMW_PointNetworkTask;
import com.example.tify.R;
import com.example.tify.ShareVar;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

public class BeforePayActivity2 extends AppCompatActivity {

// 장바구니 결제할 때 사용되는 페이지(리스트를 모두 Insert해야하므로 과부하를 줄이기 위해 BeforeActivity와 구분했음.

    String TAG = "BeforePayActivity2";

    private ArrayList<Order> list;
    private ArrayList<OrderList> orderLists;
    private ArrayList<Cart> carts;

    // layout
    TextView tv_totalOrderPrice2;
    TextView tv_totalPayPrice2;
    TextView tv_totalDiscount2;
    Button cardBtn2;
    Button btn_point;
    EditText et_point;

    // order Insert (카드이름이랑 카드번호 받기)
    String macIP;
    String urlAddr = null;
    String where = null;
    int user_uSeqNo = 0;
    int store_sSeqNo = 0;
    String oCardName;
    int oCardNo;
    String sName;

    // orderlist Insert
    String menu_mName;
    int olSizeUp;
    int olAddShot;
    String olRequest;
    int olPrice;
    int olQuantity;

    String from;
    int total;
    int number;
    int oNo;
    int point;

    String strPoint;
    String strDiscountPoint;
    String strRemainPoint;
    String strTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lmw_activity_before_pay2);

        // CartActivity로 부터 값을 받는다.
        Intent intent = getIntent();

        ShareVar shareVar = new ShareVar();
        macIP = shareVar.getMacIP();
        user_uSeqNo = intent.getIntExtra("user_uSeqNo", 0);
        store_sSeqNo = intent.getIntExtra("store_sSeqNo", 0);
        total = intent.getIntExtra("total", 0);
        sName = intent.getStringExtra("sName");
        from = intent.getStringExtra("from");

        Log.v(TAG, "유저번호 : " + user_uSeqNo);

        where = "oNo";
        urlAddr = "http://" + macIP + ":8080/tify/lmw_orderoNo_select.jsp?user_uNo=" + user_uSeqNo;
        list = connectGetData(); // order Select onCreate할 때 미리 마지막 번호 찾아와서 +1하기
        connectPoint(); // 포인트 불러오기 // 포인트 불러오기
        oNo = list.get(0).getMax() + 1;
        Log.v(TAG, "마지막 oNo : " + oNo);

        // layout 설정
        cardBtn2 = findViewById(R.id.beforePay_Btn_Card2);
        tv_totalOrderPrice2 = findViewById(R.id.beforePay_TV_totalOrderPrice2);
        tv_totalPayPrice2 = findViewById(R.id.beforePay_TV_totalPayPrice2);
        tv_totalDiscount2 = findViewById(R.id.beforePay_TV_Discount2);
        btn_point = findViewById(R.id.activity_Before2_Btn_Point);
        et_point = findViewById(R.id.beforePay_TV_Point2);

        // 값 대입
        NumberFormat moneyFormat = null;
        moneyFormat = NumberFormat.getInstance(Locale.KOREA);
        strTotal = moneyFormat.format(total);
        strPoint = moneyFormat.format(point);

        tv_totalOrderPrice2.setText(strTotal + "원");
        tv_totalPayPrice2.setText(strTotal + "원");

        // et_point 값 제한

        et_point.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Log.v(TAG, " 입력값 : " + et_point.getText().toString());
                if(et_point.getText().length() == 0){ // 아무것도 입력되지 않았을 때 입력처리
                    btn_point.setEnabled(false);
                    btn_point.setBackgroundColor(Color.parseColor("#FF999999"));
                }else { // 입력했을 때
                    Log.v(TAG, " 값!! : " + Integer.parseInt(et_point.getText().toString()));
                    if (Integer.parseInt(et_point.getText().toString()) < 1) { // 1보다 작게 입력했을 때 예외처리

                    } else {
                        int temp = Integer.parseInt(s.toString());

                        if (point < temp) { // 사용하려는 포인트가 보유 포인트보다 클 때
                            et_point.setText("");
                            Toast.makeText(BeforePayActivity2.this, "보유하신 포인트는 " + strPoint + "p 입니다.", Toast.LENGTH_SHORT).show();
                        } else {
                            if (total < temp) { // 사용하려는 포인트가 totalPrice를 초과했을 때!
                                btn_point.setEnabled(false);
                                btn_point.setBackgroundColor(Color.parseColor("#28979595"));
                                Toast.makeText(BeforePayActivity2.this, "최대 " + strTotal + "p 까지 사용가능합니다.", Toast.LENGTH_SHORT).show();
                            } else if (total >= temp){
                                btn_point.setEnabled(true);
                                btn_point.setBackgroundColor(Color.parseColor("#0084ff"));
                            }else if(point < temp){
                                et_point.setText("");
                                Toast.makeText(BeforePayActivity2.this, "보유하신 포인트는 " + strPoint + "p 입니다.", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        // 클릭 리스너
        cardBtn2.setOnClickListener(mClickListener);
        btn_point.setOnClickListener(mClickListener);

        if(point == 0){
            btn_point.setEnabled(false);
        }
        et_point.setHint(strPoint);

        carts = new ArrayList<Cart>();
        carts = CartConnectGetData(); // db를 통해 받은 데이터를 담는다.
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:{ //toolbar의 back키 눌렀을 때 동작
                finish();
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    View.OnClickListener mClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            Intent intent = null;

            int getPoint;
            int discountedPrice;
            int remainPoint;
            NumberFormat moneyFormat = NumberFormat.getInstance(Locale.KOREA);

            switch (v.getId()){
                case R.id.activity_Before2_Btn_Point:

                    if(btn_point.getText().toString().equals("적용")){
                        getPoint = Integer.parseInt(et_point.getText().toString());
                        discountedPrice = total - getPoint;
                        remainPoint = point - getPoint;

                        strTotal = moneyFormat.format(discountedPrice);
                        strDiscountPoint = moneyFormat.format(getPoint);
                        strRemainPoint = moneyFormat.format(remainPoint);

                        Log.v(TAG, "값 1 : " + strTotal);
                        Log.v(TAG, "값 2 : " + strDiscountPoint);
                        Log.v(TAG, "값 3 : " + strRemainPoint);

                        et_point.setEnabled(false);
                        et_point.setText("");
                        et_point.setHint(strRemainPoint);
                        tv_totalDiscount2.setText(strDiscountPoint + "원");
                        tv_totalPayPrice2.setText(strTotal + "원");
                        btn_point.setEnabled(true);
                        btn_point.setText("초기화");
                        btn_point.setBackgroundColor(Color.parseColor("#0084ff"));
                    }else{


                        strTotal = moneyFormat.format(total);

                        Log.v(TAG, "totalPrice : " + total);

                        et_point.setEnabled(true);
                        et_point.setText("");
                        et_point.setHint(strPoint);
                        tv_totalDiscount2.setText("0원");
                        tv_totalPayPrice2.setText(strTotal + "원");
                        btn_point.setText("적용");
                        btn_point.setEnabled(false);
                    }
                    break;

                case R.id.beforePay_Btn_Card2:

                    // 결제 부분 완료되면 결제 부분에서 JSP 실행하기 (카드번호랑 카드이름 필요)
                    // 1. 결제 완료되면 OrderListActivity로!
                    // 1-1. order 테이블 Insert
                    // 1-2. order oNo Select => oNo가 있어야 orderlist에 Insert 가능..
                    // 1-3. orderlist 테이블 Insert
                    // 2. 결제 실패하면 StoreInfoActivity로!

                    // 테스트 ---------
                    // order 테이블 Insert
                    where = "insert1";
                    int cardNum = 13153123;
                    String cardName = "신한은행";
                    urlAddr = "http://" + macIP + ":8080/tify/lmw_order_insert.jsp?user_uNo=" + user_uSeqNo + "&store_sSeqNo=" + store_sSeqNo + "&store_sName=" + sName + "&oSum=" + total + "&oCardName=" + cardName + "&oCardNo=" + cardNum + "&oReview=" + 0 + "&oStatus=" + 0;

                    connectInsertData(); // order Insert

                    // orderlist 테이블 Insert
                    for(int i = 0; i < carts.size(); i++){ // 클래스 만들어서 메소드 이용하면 더 빠를 수도?
                        where = "insert";
                        urlAddr = "http://" + macIP + ":8080/tify/lmw_orderlist_insert.jsp?user_uNo=" + user_uSeqNo + "&order_oNo=" + oNo + "&store_sSeqNo=" + store_sSeqNo + "&store_sName=" + sName + "&menu_mName=" + carts.get(i).getMenu_mName() + "&olSizeUp=" + carts.get(i).getcLSizeUp() + "&olAddShot=" + carts.get(i).getcLAddShot() + "&olRequest=" + carts.get(i).getcLRequest() + "&olPrice=" + carts.get(i).getcLPrice() + "&olQuantity=" + carts.get(i).getcLQuantity();
                        connectInsertData(); // orderlist Insert
                    }

                    // 테스트용
                    intent = new Intent(BeforePayActivity2.this, OrderListActivity.class);
                    intent.putExtra("macIP", macIP);
                    intent.putExtra("user_uSeqNo", user_uSeqNo);
                    intent.putExtra("store_sSeqNo", store_sSeqNo);
                    intent.putExtra("totalPrice", total);
                    intent.putExtra("user_uSeqNo", user_uSeqNo);
                    intent.putExtra("from", from);
                    startActivity(intent);

                    break;
            }

        }
    };
    private String connectInsertData(){
        String result = null;

        try {
            ///////////////////////////////////////////////////////////////////////////////////////
            // Date : 2020.12.25
            //
            // Description:
            //  - NetworkTask를 한곳에서 관리하기 위해 기존 CUDNetworkTask 삭제
            //  - NetworkTask의 생성자 추가 : where <- "insert"
            //
            ///////////////////////////////////////////////////////////////////////////////////////
            if(where.equals("insert")){
                LMW_OrderNetworkTask networkTask = new LMW_OrderNetworkTask(BeforePayActivity2.this, urlAddr, where);
                Object obj = networkTask.execute().get();
                result = (String)obj;
            }else{
                LMW_OrderListNetworkTask networkTask = new LMW_OrderListNetworkTask(BeforePayActivity2.this, urlAddr, where);
                Object obj = networkTask.execute().get();
                result = (String)obj;
            }

            ///////////////////////////////////////////////////////////////////////////////////////

            ///////////////////////////////////////////////////////////////////////////////////////
            // Date : 2020.12.24
            //
            // Description:
            //  - 입력 결과 값을 받기 위해 Object로 return후에 String으로 변환 하여 사용
            //
            ///////////////////////////////////////////////////////////////////////////////////////

            ///////////////////////////////////////////////////////////////////////////////////////

        }catch (Exception e){
            e.printStackTrace();
        }
        return result;
    }

    private ArrayList<Order> connectGetData(){
        ArrayList<Order> beanList = new ArrayList<Order>();

        try {
            ///////////////////////////////////////////////////////////////////////////////////////
            // Date : 2020.12.25
            //
            // Description:
            //  - NetworkTask의 생성자 추가 : where <- "select"
            //
            ///////////////////////////////////////////////////////////////////////////////////////
            LMW_OrderNetworkTask networkTask = new LMW_OrderNetworkTask(BeforePayActivity2.this, urlAddr, where);
            ///////////////////////////////////////////////////////////////////////////////////////

            Object obj = networkTask.execute().get();
            list = (ArrayList<Order>) obj;
            Log.v(TAG, "data.size() : " + list.size());

            beanList = list;

        }catch (Exception e){
            e.printStackTrace();
        }
        return beanList;
    }

    private ArrayList<Cart> CartConnectGetData(){
        ArrayList<Cart> beanList = new ArrayList<Cart>();

        where = "select";
        urlAddr = "http://" + macIP + ":8080/tify/lmw_cartlist_select.jsp?user_uSeqNo=" + user_uSeqNo;

        try {
            ///////////////////////////////////////////////////////////////////////////////////////
            // Date : 2020.12.25
            //
            // Description:
            //  - NetworkTask의 생성자 추가 : where <- "select"
            //
            ///////////////////////////////////////////////////////////////////////////////////////
            LMW_CartNetworkTask networkTask = new LMW_CartNetworkTask(BeforePayActivity2.this, urlAddr, where);
            ///////////////////////////////////////////////////////////////////////////////////////

            Object obj = networkTask.execute().get();
            carts = (ArrayList<Cart>) obj;
            Log.v(TAG, "data.size() : " + carts.size());


            beanList = carts;

        }catch (Exception e){
            e.printStackTrace();
        }
        return beanList;
    }

    private void connectPoint(){
        where = "select";
        urlAddr = "http://" + macIP + ":8080/tify/lmw_point_select.jsp?user_uSeqNo=" + user_uSeqNo;
        try {
            ///////////////////////////////////////////////////////////////////////////////////////
            // Date : 2020.12.25
            //
            // Description:
            //  - NetworkTask의 생성자 추가 : where <- "select"
            //
            ///////////////////////////////////////////////////////////////////////////////////////
            LMW_PointNetworkTask networkTask = new LMW_PointNetworkTask(BeforePayActivity2.this, urlAddr, where);
            ///////////////////////////////////////////////////////////////////////////////////////

            Object obj = networkTask.execute().get();
            point = (Integer) obj;
            Log.v(TAG, "point) : " + point);

        }catch (Exception e){
            e.printStackTrace();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        ActionBar actionBar = getSupportActionBar();
        actionBar.show();
        // Custom Actionbar를 사용하기 위해 CustomEnabled을 true 시키고 필요 없는 것은 false 시킨다
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(false);            //액션바 아이콘을 업 네비게이션 형태로 표시합니다.
        actionBar.setDisplayShowTitleEnabled(false);        //액션바에 표시되는 제목의 표시유무를 설정합니다.
        actionBar.setDisplayShowHomeEnabled(false);            //홈 아이콘을 숨김처리합니다.

        //layout을 가지고 와서 actionbar에 포팅을 시킵니다.
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        View actionbar = inflater.inflate(R.layout.cha_custom_actionbar, null);

        actionBar.setCustomView(actionbar);
        TextView title = findViewById(R.id.title);
        title.setText("주문하기");

        ImageButton cart = findViewById(R.id.cart);
        cart.setVisibility(View.INVISIBLE);
        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });


//         장바구니 없애려면 위에거 살리면 됨
        ImageButton btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        //액션바 양쪽 공백 없애기
        Toolbar parent = (Toolbar) actionbar.getParent();
        parent.setContentInsetsAbsolute(0, 0);
        return true;
    }
}